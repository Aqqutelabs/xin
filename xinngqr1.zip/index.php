<?php
require_once __DIR__ . '/config.php';
session_start();
$isSignedIn = !empty($_SESSION['user_id']);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= htmlspecialchars($APP_NAME) ?> — Smart links, QR codes, and creator pages</title>
  <meta name="description" content="Create dynamic QR codes, branded short links, and polished creator pages with Xinng. Perfect for personal brands, creators, freelancers, and professionals.">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="landing-page">
  <div class="landing-bg-glow" aria-hidden="true"></div>

  <header class="landing-nav">
    <div class="landing-nav__inner">
      <a class="landing-brand" href="index.php">
        <span class="landing-brand__mark">X</span>
        <span class="landing-brand__word">xin.ng</span>
      </a>
      <nav class="landing-nav__links" aria-label="Primary navigation">
        <a href="#features">Features</a>
        <a href="#how-it-works">How it works</a>
        <a href="#contact">Contact</a>
        <?php if ($isSignedIn): ?>
          <a class="landing-btn landing-btn--primary" href="dashboard.php">Dashboard</a>
        <?php else: ?>
          <a class="landing-btn landing-btn--secondary" href="signin.php">Login</a>
          <a class="landing-btn landing-btn--primary" href="signup.php">Sign up</a>
        <?php endif; ?>
      </nav>
    </div>
  </header>

  <main class="landing-shell">
    <section class="landing-hero">
      <div class="landing-hero__copy">
        <p class="landing-eyebrow">A smart link and QR platform for creators</p>
        <h1>Create smart links, QR codes, and creator pages.</h1>
        <p class="landing-subtext">Build a polished profile for your audience, connect your socials, and share a branded QR experience in minutes.</p>
        <p class="landing-mini-copy">Whether you are a creator, freelancer, personal brand, or small business, Xinng helps you turn offline attention into online action.</p>

        <div class="landing-pill-row" aria-label="Highlights">
          <span class="landing-pill">Creator pages</span>
          <span class="landing-pill">Branded short links</span>
          <span class="landing-pill">Custom QR codes</span>
        </div>

        <div class="landing-actions">
          <a class="landing-btn landing-btn--primary" href="pages.php">Create a Creator Page</a>
          <a class="landing-btn landing-btn--secondary" href="q.php">Create QR Code</a>
        </div>

        <div class="landing-feature-grid" id="features">
          <article class="landing-card">
            <h3>Creator pages</h3>
            <p>Turn your links, socials, portfolio, and offers into a clean mobile-first page that feels personal and branded.</p>
          </article>
          <article class="landing-card">
            <h3>Smart links</h3>
            <p>Use short, branded links that make every share feel polished and memorable.</p>
          </article>
          <article class="landing-card">
            <h3>QR-ready sharing</h3>
            <p>Connect your offline audience to your online presence with custom QR codes built for creators and businesses.</p>
          </article>
        </div>
      </div>

      <aside class="landing-widget" id="how-it-works">
        <div class="landing-widget__header">
          <div class="landing-widget__icon">QR</div>
          <div>
            <h2>Live QR generator</h2>
            <p>Interactive preview</p>
          </div>
        </div>
        <div class="landing-widget__divider"></div>
        <form class="landing-form" id="qrForm" method="post" action="create_qr.php">
          <label class="landing-form__label" for="destination">Destination URL</label>
          <input id="destination" name="destination" class="landing-form__input" type="url" value="https://" placeholder="https://example.com" />

          <label class="landing-form__label" for="qrType">QR Type</label>
          <select id="qrType" name="qr_type" class="landing-form__select">
            <option>Website</option>
            <option>Product</option>
            <option>Campaign</option>
          </select>

          <label class="landing-form__label" for="style">Optional customization</label>
          <select id="style" name="style" class="landing-form__select">
            <option>Standard</option>
            <option>Bold</option>
            <option>Minimal</option>
          </select>

          <button class="landing-btn landing-btn--primary landing-btn--full" type="submit">Create QR Code</button>
        </form>

        <div class="landing-preview" aria-live="polite">
          <p class="landing-preview__eyebrow">Live preview</p>
          <div class="landing-qr-preview">
            <div class="landing-qr-preview__box"></div>
            <div class="landing-qr-preview__text">
              <strong id="previewTitle">Ready to generate</strong>
              <p id="previewCopy">Your QR code updates as you type.</p>
            </div>
          </div>
        </div>
      </aside>
    </section>

    <section class="landing-section landing-section--soft" aria-label="Trusted by companies">
      <div class="landing-trust-row">
        <span>Trusted by companies</span>
        <div class="landing-trust-badges">
          <span>Northstar</span>
          <span>Loop Labs</span>
          <span>Studio Nine</span>
          <span>Altura</span>
        </div>
      </div>
    </section>

    <section class="landing-section" id="features">
      <div class="landing-section__heading">
        <p class="landing-eyebrow">Everything you need in one platform</p>
        <h2>One lightweight workflow for QR codes, short links, and pages.</h2>
      </div>
      <div class="landing-feature-grid landing-feature-grid--expanded">
        <article class="landing-card">
          <h3>QR Codes</h3>
          <p>Create dynamic and static QR codes with full customization for every campaign.</p>
        </article>
        <article class="landing-card">
          <h3>Short Links</h3>
          <p>Create branded links like xin.ng/sheltercon to make every share feel polished.</p>
        </article>
        <article class="landing-card">
          <h3>Pages</h3>
          <p>Build mobile-first landing pages for creators, businesses, and product launches.</p>
        </article>
        <article class="landing-card">
          <h3>Analytics</h3>
          <p>Track scans, clicks, and engagement as your audience grows.</p>
        </article>
        <article class="landing-card">
          <h3>Custom Branding</h3>
          <p>Add logos, colors, and styles to QR codes and pages so they look unmistakably yours.</p>
        </article>
        <article class="landing-card">
          <h3>Fast Launch</h3>
          <p>Move from idea to live share in minutes with a streamlined, no-fuss experience.</p>
        </article>
      </div>
    </section>

    <section class="landing-section" id="benefits">
      <div class="landing-section__heading">
        <p class="landing-eyebrow">Benefits</p>
        <h2>A simple QR workflow for modern campaigns and everyday sharing.</h2>
      </div>
      <div class="landing-benefits-grid">
        <article class="landing-benefit">
          <h3>Fast to launch</h3>
          <p>Generate a QR code in seconds and use it right away for menus, events, promos, or product pages.</p>
        </article>
        <article class="landing-benefit">
          <h3>Easy to customize</h3>
          <p>Adjust the destination and style so each code feels aligned with your brand.</p>
        </article>
        <article class="landing-benefit">
          <h3>Built for growth</h3>
          <p>Upgrade later for analytics, scans, and richer campaign reporting.</p>
        </article>
      </div>
    </section>

    <section class="landing-section landing-section--alt" id="stories">
      <div class="landing-section__heading">
        <p class="landing-eyebrow">Testimonials</p>
        <h2>Trusted by creators, marketers, and growing businesses.</h2>
      </div>
      <div class="landing-testimonials-grid">
        <article class="landing-testimonial">
          <p>“Xinng gave us a polished QR experience that felt faster and cleaner than anything else we tried.”</p>
          <strong>— Product marketer</strong>
        </article>
        <article class="landing-testimonial">
          <p>“We launched a campaign in one afternoon and had branded links, QR codes, and a page ready to go.”</p>
          <strong>— Creator studio founder</strong>
        </article>
      </div>
    </section>

    <section class="landing-section landing-section--cta">
      <div class="landing-cta">
        <div>
          <p class="landing-eyebrow">Ready to go live?</p>
          <h2>Make your first QR code in seconds.</h2>
        </div>
        <a class="landing-btn landing-btn--primary" href="q.php">Create QR Code</a>
      </div>
    </section>
  </main>

  <footer class="landing-footer" id="contact">
    <div class="landing-footer__inner">
      <p>Built for fast launches, polished links, and modern campaigns.</p>
      <a class="landing-btn landing-btn--primary" href="q.php">Create a QR code now</a>
    </div>
  </footer>

  <script>
    (function () {
      const destinationInput = document.getElementById('destination');
      const qrTypeSelect = document.getElementById('qrType');
      const styleSelect = document.getElementById('style');
      const previewTitle = document.getElementById('previewTitle');
      const previewCopy = document.getElementById('previewCopy');

      if (!destinationInput || !qrTypeSelect || !styleSelect || !previewTitle || !previewCopy) return;

      const updatePreview = () => {
        const destination = destinationInput.value.trim() || 'https://';
        const type = qrTypeSelect.value;
        const style = styleSelect.value;
        previewTitle.textContent = `${type} QR ready`;
        previewCopy.textContent = `${style} style • ${destination}`;
      };

      [destinationInput, qrTypeSelect, styleSelect].forEach((field) => {
        field.addEventListener('input', updatePreview);
        field.addEventListener('change', updatePreview);
      });

      updatePreview();
    })();
  </script>
</body>
</html>
